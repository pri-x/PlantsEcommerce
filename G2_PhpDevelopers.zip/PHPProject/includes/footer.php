
<footer class="bg-dark text-white text-center text-lg-start mt-5">

    <div class="text-center p-3 bg-secondary">
        <p class="mb-0">© 2024 E-Commerce Website. All rights reserved.</p>
    </div>
</footer>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>

</html>