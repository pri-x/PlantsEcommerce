<?php 

require("./fpdf.php");

$pdf = new FPDF();
$pdf->AddPage();

$pdf->SetFont('Arial','',12);
$pdf->Cell(0,5,'Regular normal arial text here, size 12',0,1,'L');
$pdf->Ln();

$pdf->SetFont('Arial','IBU',20);
$pdf->Cell(0,15,'THis is Bold, Underline, Italicised text size 20',0,0,'L');
$pdf->Ln();

$pdf->SetFont('Arial','IU',15);
$pdf->Cell(0,5,'This is Italicised 15t Times',0,0,'L');

$pdf->Output();
?>